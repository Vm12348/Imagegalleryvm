# React JS Image Gallery With Full Screen Modal

React JS gallery by WebStylePress, that takes array of images and shows images thumbnails. On click of images full screen gallery appears and you can navigate through available images.

## How to Use

Clone or download repo
NodeJS / NPM / Yarn should be installed in your PC

Open terminal or Git for Windows (Git Bash)
Run these commands:

### Install Dependencies

yarn install

OR

npm install

### Run app

yarn start

OR

npm start

### YouTube Tutorial URL

Title: Responsive Image Gallery in React JS | NO External Package | Plug & Play ReactJS Gallery

to be updated
